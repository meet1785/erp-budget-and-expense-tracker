"""
K-Means Clustering - Complete Example
=====================================
This example demonstrates how to use K-Means Clustering for unsupervised learning tasks.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs, make_circles
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, adjusted_rand_score
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA

print("K-Means Clustering Example")
print("=" * 30)

# Example 1: Simple K-Means with Synthetic Data
print("\n1. Creating Synthetic Dataset...")
X, y_true = make_blobs(n_samples=300, centers=4, cluster_std=0.8, 
                       random_state=42, n_features=2)

print(f"Dataset shape: {X.shape}")
print(f"Number of true clusters: {len(np.unique(y_true))}")

# Visualize the original data
plt.figure(figsize=(15, 10))

# Plot 1: Original data with true clusters
plt.subplot(2, 3, 1)
plt.scatter(X[:, 0], X[:, 1], c=y_true, cmap='viridis', alpha=0.7)
plt.title('Original Data with True Clusters')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.colorbar()

# Apply K-Means clustering
print("\n2. Applying K-Means Clustering...")
kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
y_pred = kmeans.fit_predict(X)

# Get cluster centers
centers = kmeans.cluster_centers_

print(f"Cluster centers:")
for i, center in enumerate(centers):
    print(f"Cluster {i}: ({center[0]:.2f}, {center[1]:.2f})")

# Plot 2: K-Means results
plt.subplot(2, 3, 2)
plt.scatter(X[:, 0], X[:, 1], c=y_pred, cmap='viridis', alpha=0.7)
plt.scatter(centers[:, 0], centers[:, 1], c='red', marker='x', 
           s=200, linewidths=3, label='Centroids')
plt.title('K-Means Clustering Results')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.colorbar()

# Evaluate clustering performance
silhouette_avg = silhouette_score(X, y_pred)
ari_score = adjusted_rand_score(y_true, y_pred)

print(f"\n3. Clustering Performance:")
print(f"Silhouette Score: {silhouette_avg:.4f}")
print(f"Adjusted Rand Index: {ari_score:.4f}")
print(f"Inertia (Within-cluster sum of squares): {kmeans.inertia_:.2f}")

# Example 2: Finding Optimal Number of Clusters (Elbow Method)
print("\n" + "="*50)
print("FINDING OPTIMAL NUMBER OF CLUSTERS")
print("="*50)

# Test different numbers of clusters
k_range = range(1, 11)
inertias = []
silhouette_scores = []

for k in k_range:
    kmeans_temp = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans_temp.fit(X)
    inertias.append(kmeans_temp.inertia_)
    
    if k > 1:  # Silhouette score requires at least 2 clusters
        sil_score = silhouette_score(X, kmeans_temp.labels_)
        silhouette_scores.append(sil_score)
    else:
        silhouette_scores.append(0)

# Plot 3: Elbow curve
plt.subplot(2, 3, 3)
plt.plot(k_range, inertias, 'bo-')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Inertia')
plt.title('Elbow Method for Optimal k')
plt.grid(True)

# Plot 4: Silhouette score
plt.subplot(2, 3, 4)
plt.plot(k_range, silhouette_scores, 'ro-')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Silhouette Score')
plt.title('Silhouette Score vs Number of Clusters')
plt.grid(True)

# Find optimal k using elbow method (simple approach)
# Calculate the rate of change in inertia
inertia_diff = np.diff(inertias)
optimal_k = np.argmin(inertia_diff[1:]) + 3  # +3 because we start from k=1 and take diff twice

print(f"\nOptimal number of clusters (Elbow method): {optimal_k}")
print(f"Best silhouette score: {max(silhouette_scores):.4f} at k={silhouette_scores.index(max(silhouette_scores)) + 1}")

# Example 3: K-Means on Higher Dimensional Data
print("\n" + "="*50)
print("K-MEANS ON HIGHER DIMENSIONAL DATA")
print("="*50)

# Create higher dimensional data
X_high, y_true_high = make_blobs(n_samples=500, centers=3, n_features=5, 
                                cluster_std=1.0, random_state=42)

print(f"High-dimensional dataset shape: {X_high.shape}")

# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_high)

# Apply K-Means
kmeans_high = KMeans(n_clusters=3, random_state=42, n_init=10)
y_pred_high = kmeans_high.fit_predict(X_scaled)

# Evaluate
silhouette_high = silhouette_score(X_scaled, y_pred_high)
ari_high = adjusted_rand_score(y_true_high, y_pred_high)

print(f"High-dimensional clustering results:")
print(f"Silhouette Score: {silhouette_high:.4f}")
print(f"Adjusted Rand Index: {ari_high:.4f}")

# Use PCA for visualization
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Plot 5: PCA visualization of high-dimensional clustering
plt.subplot(2, 3, 5)
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y_pred_high, cmap='viridis', alpha=0.7)
plt.title('High-Dim Data Clustering (PCA Projection)')
plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.2%} variance)')
plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.2%} variance)')
plt.colorbar()

# Example 4: Customer Segmentation Example
print("\n" + "="*50)
print("REAL-WORLD EXAMPLE: CUSTOMER SEGMENTATION")
print("="*50)

# Create realistic customer data
np.random.seed(42)
n_customers = 1000

# Generate customer features
age = np.random.normal(40, 15, n_customers)
annual_income = np.random.normal(50000, 20000, n_customers)
spending_score = np.random.uniform(1, 100, n_customers)
purchase_frequency = np.random.poisson(12, n_customers)

# Create DataFrame
customer_data = pd.DataFrame({
    'Age': age,
    'Annual_Income': annual_income,
    'Spending_Score': spending_score,
    'Purchase_Frequency': purchase_frequency
})

# Remove negative values and outliers
customer_data = customer_data[(customer_data['Age'] > 18) & (customer_data['Age'] < 80)]
customer_data = customer_data[customer_data['Annual_Income'] > 20000]
customer_data = customer_data[customer_data['Purchase_Frequency'] > 0]

print("Customer Data Sample:")
print(customer_data.head())
print(f"\nDataset shape: {customer_data.shape}")

# Standardize the features
customer_scaled = StandardScaler().fit_transform(customer_data)

# Find optimal number of clusters for customer data
k_range_customer = range(2, 9)
inertias_customer = []
silhouette_customer = []

for k in k_range_customer:
    kmeans_temp = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans_temp.fit(customer_scaled)
    inertias_customer.append(kmeans_temp.inertia_)
    silhouette_customer.append(silhouette_score(customer_scaled, kmeans_temp.labels_))

# Apply K-Means with optimal clusters
optimal_k_customer = k_range_customer[np.argmax(silhouette_customer)]
print(f"\nOptimal number of customer segments: {optimal_k_customer}")

kmeans_customer = KMeans(n_clusters=optimal_k_customer, random_state=42, n_init=10)
customer_clusters = kmeans_customer.fit_predict(customer_scaled)

# Add cluster labels to original data
customer_data['Cluster'] = customer_clusters

# Analyze clusters
print(f"\nCustomer Segment Analysis:")
cluster_summary = customer_data.groupby('Cluster').agg({
    'Age': ['mean', 'std'],
    'Annual_Income': ['mean', 'std'],
    'Spending_Score': ['mean', 'std'],
    'Purchase_Frequency': ['mean', 'std']
}).round(2)

print(cluster_summary)

# Plot 6: Customer segments (using first two features)
plt.subplot(2, 3, 6)
scatter = plt.scatter(customer_data['Annual_Income'], customer_data['Spending_Score'], 
                     c=customer_clusters, cmap='viridis', alpha=0.7)
plt.xlabel('Annual Income')
plt.ylabel('Spending Score')
plt.title('Customer Segmentation')
plt.colorbar(scatter)

plt.tight_layout()
plt.savefig('kmeans_clustering_analysis.png', dpi=300, bbox_inches='tight')
print('Saved: kmeans_clustering_analysis.png')
plt.close()

# Create detailed customer segment profiles
print(f"\n4. Customer Segment Profiles:")
for cluster_id in range(optimal_k_customer):
    cluster_data = customer_data[customer_data['Cluster'] == cluster_id]
    print(f"\nSegment {cluster_id} (n={len(cluster_data)}):")
    print(f"  Average Age: {cluster_data['Age'].mean():.1f} years")
    print(f"  Average Income: ${cluster_data['Annual_Income'].mean():,.0f}")
    print(f"  Average Spending Score: {cluster_data['Spending_Score'].mean():.1f}")
    print(f"  Average Purchase Frequency: {cluster_data['Purchase_Frequency'].mean():.1f} times/year")

# Example predictions
print(f"\n5. Predicting Cluster for New Customers:")

# Create example new customers
new_customers = np.array([
    [25, 30000, 80, 15],  # Young, low income, high spending
    [45, 70000, 40, 8],   # Middle-aged, high income, low spending
    [35, 55000, 65, 12]   # Middle-aged, medium income, medium spending
])

# Scale the new customer data
new_customers_scaled = StandardScaler().fit(customer_data[['Age', 'Annual_Income', 'Spending_Score', 'Purchase_Frequency']]).transform(new_customers)
new_clusters = kmeans_customer.predict(new_customers_scaled)

for i, (customer, cluster) in enumerate(zip(new_customers, new_clusters)):
    print(f"\nNew Customer {i+1}:")
    print(f"  Age: {customer[0]:.0f}, Income: ${customer[1]:,.0f}")
    print(f"  Spending Score: {customer[2]:.1f}, Purchase Freq: {customer[3]:.0f}")
    print(f"  Assigned to Segment: {cluster}")

# Cluster centers in original scale
print(f"\n6. Cluster Centers (Original Scale):")
cluster_centers_original = StandardScaler().fit(customer_data[['Age', 'Annual_Income', 'Spending_Score', 'Purchase_Frequency']]).inverse_transform(kmeans_customer.cluster_centers_)

for i, center in enumerate(cluster_centers_original):
    print(f"Segment {i} Center:")
    print(f"  Age: {center[0]:.1f}, Income: ${center[1]:,.0f}")
    print(f"  Spending Score: {center[2]:.1f}, Purchase Freq: {center[3]:.1f}")

print("\n" + "="*50)
print("K-Means Clustering Example Complete!")
print("Files saved:")
print("- kmeans_clustering_analysis.png")
print("="*50)