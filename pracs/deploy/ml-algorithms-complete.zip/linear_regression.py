"""
Linear Regression - Complete Example
====================================
This example demonstrates how to use Linear Regression for prediction tasks.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.datasets import make_regression
import matplotlib.pyplot as plt
import seaborn as sns

print("Linear Regression Example")
print("=" * 30)

# Example 1: Simple Linear Regression with Synthetic Data
print("\n1. Creating Synthetic Dataset...")
X, y = make_regression(n_samples=1000, n_features=1, noise=20, random_state=42)

print(f"Dataset shape: {X.shape}")
print(f"Target shape: {y.shape}")

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

print(f"Training set size: {X_train.shape[0]} samples")
print(f"Test set size: {X_test.shape[0]} samples")

# Create and train the Linear Regression model
print("\n2. Training Linear Regression Model...")
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

# Make predictions
y_pred = lr_model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"\n3. Model Performance:")
print(f"Mean Squared Error (MSE): {mse:.4f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.4f}")
print(f"Mean Absolute Error (MAE): {mae:.4f}")
print(f"R² Score: {r2:.4f}")

# Model parameters
print(f"\n4. Model Parameters:")
print(f"Coefficient (slope): {lr_model.coef_[0]:.4f}")
print(f"Intercept: {lr_model.intercept_:.4f}")
print(f"Equation: y = {lr_model.coef_[0]:.4f}x + {lr_model.intercept_:.4f}")

# Visualize the results
plt.figure(figsize=(12, 8))

# Plot 1: Scatter plot with regression line
plt.subplot(2, 2, 1)
plt.scatter(X_test, y_test, alpha=0.6, label='Actual')
plt.scatter(X_test, y_pred, alpha=0.6, label='Predicted')
plt.plot(X_test, y_pred, 'r-', linewidth=2, label='Regression Line')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.title('Linear Regression: Actual vs Predicted')
plt.legend()

# Plot 2: Residuals plot
plt.subplot(2, 2, 2)
residuals = y_test - y_pred
plt.scatter(y_pred, residuals, alpha=0.6)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel('Predicted Values')
plt.ylabel('Residuals')
plt.title('Residuals Plot')

# Plot 3: Actual vs Predicted
plt.subplot(2, 2, 3)
plt.scatter(y_test, y_pred, alpha=0.6)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', linewidth=2)
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs Predicted Values')

# Plot 4: Distribution of residuals
plt.subplot(2, 2, 4)
plt.hist(residuals, bins=30, alpha=0.7, edgecolor='black')
plt.xlabel('Residuals')
plt.ylabel('Frequency')
plt.title('Distribution of Residuals')

plt.tight_layout()
plt.savefig('linear_regression_analysis.png', dpi=300, bbox_inches='tight')
print('Saved: linear_regression_analysis.png')
plt.close()

# Example 2: Multiple Linear Regression
print("\n" + "="*50)
print("MULTIPLE LINEAR REGRESSION EXAMPLE")
print("="*50)

# Create multiple feature dataset
X_multi, y_multi = make_regression(n_samples=1000, n_features=3, noise=15, random_state=42)
feature_names = ['Feature_1', 'Feature_2', 'Feature_3']

# Convert to DataFrame for better visualization
df = pd.DataFrame(X_multi, columns=feature_names)
df['Target'] = y_multi

print(f"\nDataset Info:")
print(df.describe())

# Split the data
X_train_multi, X_test_multi, y_train_multi, y_test_multi = train_test_split(
    X_multi, y_multi, test_size=0.3, random_state=42)

# Train multiple linear regression model
lr_multi = LinearRegression()
lr_multi.fit(X_train_multi, y_train_multi)

# Make predictions
y_pred_multi = lr_multi.predict(X_test_multi)

# Evaluate
mse_multi = mean_squared_error(y_test_multi, y_pred_multi)
r2_multi = r2_score(y_test_multi, y_pred_multi)

print(f"\nMultiple Linear Regression Results:")
print(f"Mean Squared Error: {mse_multi:.4f}")
print(f"R² Score: {r2_multi:.4f}")

# Model parameters
print(f"\nModel Parameters:")
print(f"Intercept: {lr_multi.intercept_:.4f}")
for i, coef in enumerate(lr_multi.coef_):
    print(f"Coefficient for {feature_names[i]}: {coef:.4f}")

# Create equation string
equation = f"y = {lr_multi.intercept_:.4f}"
for i, coef in enumerate(lr_multi.coef_):
    sign = "+" if coef >= 0 else ""
    equation += f" {sign}{coef:.4f}*{feature_names[i]}"
print(f"\nEquation: {equation}")

# Feature importance (absolute coefficients)
feature_importance = np.abs(lr_multi.coef_)
plt.figure(figsize=(10, 6))
plt.bar(feature_names, feature_importance)
plt.title('Feature Importance (Absolute Coefficients)')
plt.xlabel('Features')
plt.ylabel('Absolute Coefficient Value')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('linear_regression_feature_importance.png', dpi=300, bbox_inches='tight')
print('Saved: linear_regression_feature_importance.png')
plt.close()

# Example 3: Real-world example with Boston Housing dataset
print("\n" + "="*50)
print("REAL-WORLD EXAMPLE: CUSTOM HOUSING DATA")
print("="*50)

# Create realistic housing data
np.random.seed(42)
n_samples = 500

# Generate realistic housing features
area = np.random.normal(2000, 500, n_samples)  # Square feet
bedrooms = np.random.randint(1, 6, n_samples)  # Number of bedrooms
age = np.random.uniform(0, 50, n_samples)      # Age of house
location_score = np.random.uniform(1, 10, n_samples)  # Location desirability score

# Create realistic price based on features (with some noise)
price = (area * 150 + bedrooms * 10000 - age * 1000 + location_score * 5000 + 
         np.random.normal(0, 20000, n_samples))

# Create DataFrame
housing_data = pd.DataFrame({
    'Area_SqFt': area,
    'Bedrooms': bedrooms, 
    'Age_Years': age,
    'Location_Score': location_score,
    'Price': price
})

print("Housing Dataset Sample:")
print(housing_data.head())

print(f"\nDataset Statistics:")
print(housing_data.describe())

# Prepare features and target
X_housing = housing_data[['Area_SqFt', 'Bedrooms', 'Age_Years', 'Location_Score']]
y_housing = housing_data['Price']

# Split the data
X_train_house, X_test_house, y_train_house, y_test_house = train_test_split(
    X_housing, y_housing, test_size=0.3, random_state=42)

# Train model
lr_housing = LinearRegression()
lr_housing.fit(X_train_house, y_train_house)

# Make predictions
y_pred_house = lr_housing.predict(X_test_house)

# Evaluate
mse_house = mean_squared_error(y_test_house, y_pred_house)
r2_house = r2_score(y_test_house, y_pred_house)
rmse_house = np.sqrt(mse_house)

print(f"\nHousing Price Prediction Results:")
print(f"Mean Squared Error: ${mse_house:,.2f}")
print(f"Root Mean Squared Error: ${rmse_house:,.2f}")
print(f"R² Score: {r2_house:.4f}")

# Model coefficients
print(f"\nModel Coefficients:")
print(f"Intercept: ${lr_housing.intercept_:,.2f}")
for feature, coef in zip(X_housing.columns, lr_housing.coef_):
    print(f"{feature}: ${coef:,.2f}")

# Example predictions
print(f"\n5. Example Predictions:")
print("Predicting house prices for new samples...")

# Create example houses
example_houses = np.array([
    [1500, 3, 10, 7.5],  # 1500 sq ft, 3 bedrooms, 10 years old, good location
    [2500, 4, 5, 9.0],   # 2500 sq ft, 4 bedrooms, 5 years old, excellent location
    [1200, 2, 25, 5.0]   # 1200 sq ft, 2 bedrooms, 25 years old, average location
])

example_predictions = lr_housing.predict(example_houses)

for i, (house, pred) in enumerate(zip(example_houses, example_predictions)):
    print(f"\nHouse {i+1}:")
    print(f"  Area: {house[0]:.0f} sq ft")
    print(f"  Bedrooms: {house[1]:.0f}")
    print(f"  Age: {house[2]:.0f} years")
    print(f"  Location Score: {house[3]:.1f}")
    print(f"  Predicted Price: ${pred:,.2f}")

# Correlation matrix
plt.figure(figsize=(10, 8))
correlation_data = housing_data.corr()
sns.heatmap(correlation_data, annot=True, cmap='coolwarm', center=0, 
            square=True, linewidths=0.5)
plt.title('Housing Data Correlation Matrix')
plt.tight_layout()
plt.savefig('housing_correlation_matrix.png', dpi=300, bbox_inches='tight')
print('Saved: housing_correlation_matrix.png')
plt.close()

print("\n" + "="*50)
print("Linear Regression Example Complete!")
print("Files saved:")
print("- linear_regression_analysis.png")
print("- linear_regression_feature_importance.png")
print("- housing_correlation_matrix.png")
print("="*50)