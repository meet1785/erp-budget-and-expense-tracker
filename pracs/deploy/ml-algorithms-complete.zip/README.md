# Machine Learning Algorithms - Complete Examples

This repository contains complete, easy-to-understand implementations of fundamental machine learning algorithms with practical examples and visualizations.

## Contents

### 1. Decision Tree Classifier (`decision_tree_classifier.py`)
- **What it does**: Classifies data by creating a tree-like model of decisions
- **Key Features**:
  - Synthetic dataset example with performance metrics
  - Real-world Iris dataset classification
  - Feature importance analysis
  - Tree structure visualization
  - Confusion matrix and classification reports
- **Applications**: Medical diagnosis, email spam detection, customer classification
- **Output Files**: 
  - `decision_tree_confusion_matrix.png`
  - `decision_tree_feature_importance.png`
  - `decision_tree_structure.png`

### 2. Linear Regression (`linear_regression.py`)
- **What it does**: Predicts continuous values by finding the best linear relationship
- **Key Features**:
  - Simple and multiple linear regression examples
  - Model performance evaluation (MSE, RMSE, R²)
  - Residual analysis and visualizations
  - Real-world housing price prediction
  - Feature correlation analysis
- **Applications**: Price prediction, sales forecasting, risk analysis
- **Output Files**:
  - `linear_regression_analysis.png`
  - `linear_regression_feature_importance.png`
  - `housing_correlation_matrix.png`

### 3. K-Means Clustering (`kmeans_clustering.py`)
- **What it does**: Groups similar data points into clusters
- **Key Features**:
  - Elbow method for optimal cluster selection
  - Silhouette score analysis
  - Customer segmentation example
  - High-dimensional data clustering with PCA
  - Cluster profiling and interpretation
- **Applications**: Customer segmentation, market research, image segmentation
- **Output Files**:
  - `kmeans_clustering_analysis.png`

### 4. Hierarchical Clustering (`hierarchical_clustering.py`)
- **What it does**: Creates hierarchical clusters using different linkage methods
- **Key Features**:
  - Different linkage methods comparison (Ward, Complete, Average, Single)
  - Dendrogram visualization and analysis
  - Distance matrix visualization
  - Customer segmentation with detailed profiling
  - Comparison with K-Means clustering
- **Applications**: Phylogenetic analysis, social network analysis, market segmentation
- **Output Files**:
  - `hierarchical_clustering_analysis.png`
  - `hierarchical_dendrograms.png`

### 5. Apriori Algorithm (`apriori_algorithm.py`)
- **What it does**: Finds frequent patterns and association rules in transactional data
- **Key Features**:
  - Custom Apriori implementation from scratch
  - Market basket analysis with realistic grocery data
  - Association rule generation with confidence and lift metrics
  - Professional implementation using mlxtend library
  - Business insights and recommendations
- **Applications**: Market basket analysis, recommendation systems, web usage patterns
- **Output Files**:
  - `apriori_analysis.png`
  - `apriori_rules_analysis.png` (if mlxtend available)
  - `frequent_itemsets.csv`
  - `association_rules.csv`

## How to Run

### Prerequisites
```bash
pip install numpy pandas matplotlib seaborn scikit-learn scipy
```

### Optional (for advanced Apriori features)
```bash
pip install mlxtend
```

### Running the Examples
1. Navigate to your pracs folder
2. Run any algorithm:
```bash
python decision_tree_classifier.py
python linear_regression.py
python kmeans_clustering.py
python hierarchical_clustering.py
python apriori_algorithm.py
```

## Key Learning Concepts

### Supervised Learning
- **Decision Trees**: Learn decision rules from data features
- **Linear Regression**: Model linear relationships between variables

### Unsupervised Learning
- **K-Means**: Partition data into k clusters
- **Hierarchical Clustering**: Build cluster hierarchy using distance measures

### Association Rule Mining
- **Apriori Algorithm**: Find frequent patterns and relationships in data

## Performance Metrics Explained

### Classification Metrics (Decision Tree)
- **Accuracy**: Overall correctness of predictions
- **Precision**: True positives / (True positives + False positives)
- **Recall**: True positives / (True positives + False negatives)
- **F1-Score**: Harmonic mean of precision and recall

### Regression Metrics (Linear Regression)
- **MSE (Mean Squared Error)**: Average squared differences between actual and predicted
- **RMSE (Root MSE)**: Square root of MSE (same units as target)
- **R² Score**: Proportion of variance explained by the model

### Clustering Metrics
- **Silhouette Score**: Measure of cluster quality (-1 to 1, higher is better)
- **Inertia**: Within-cluster sum of squared distances to centroids
- **Adjusted Rand Index**: Similarity between predicted and true clusters

### Association Rule Metrics
- **Support**: Frequency of itemset in transactions
- **Confidence**: P(consequent|antecedent) - reliability of rule
- **Lift**: Confidence/P(consequent) - strength of association

## Real-World Applications

### Business Applications
1. **Customer Segmentation**: Group customers for targeted marketing
2. **Price Prediction**: Estimate product/service prices
3. **Market Basket Analysis**: Understand buying patterns
4. **Recommendation Systems**: Suggest products based on patterns

### Technical Applications
1. **Anomaly Detection**: Identify outliers in data
2. **Feature Selection**: Determine most important variables
3. **Data Exploration**: Understand data structure and relationships
4. **Predictive Analytics**: Forecast future trends

## Tips for Practical Use

### Data Preparation
- Always clean and preprocess your data
- Handle missing values appropriately
- Scale features when necessary (especially for clustering)
- Split data into training and testing sets

### Model Selection
- **Decision Trees**: Good for interpretable models, handles non-linear relationships
- **Linear Regression**: Best for linear relationships, simple and fast
- **K-Means**: When you know approximate number of clusters
- **Hierarchical**: When you need cluster hierarchy or don't know cluster count
- **Apriori**: For transactional data and pattern discovery

### Avoiding Common Pitfalls
- **Overfitting**: Use appropriate tree depth, validation sets
- **Underfitting**: Ensure model complexity matches data complexity
- **Scaling**: Normalize features for distance-based algorithms
- **Evaluation**: Always validate on unseen data

## Next Steps

After understanding these basics:
1. Try ensemble methods (Random Forest, Gradient Boosting)
2. Explore deep learning with neural networks
3. Learn advanced preprocessing techniques
4. Study cross-validation and hyperparameter tuning
5. Implement real-time prediction systems

## Files Generated

Each script creates:
- Detailed console output with explanations
- Visualizations saved as PNG files
- CSV files with results (where applicable)
- Performance metrics and model insights

Happy Learning! 🚀