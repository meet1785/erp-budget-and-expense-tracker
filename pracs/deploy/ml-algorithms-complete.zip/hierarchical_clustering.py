"""
Hierarchical Clustering - Complete Example
==========================================
This example demonstrates how to use Hierarchical Clustering for unsupervised learning tasks.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering
from sklearn.datasets import make_blobs, make_circles
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, adjusted_rand_score
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from scipy.spatial.distance import pdist, squareform

print("Hierarchical Clustering Example")
print("=" * 35)

# Example 1: Basic Hierarchical Clustering
print("\n1. Creating Synthetic Dataset...")
X, y_true = make_blobs(n_samples=150, centers=4, cluster_std=1.0, 
                       random_state=42, n_features=2)

print(f"Dataset shape: {X.shape}")
print(f"Number of true clusters: {len(np.unique(y_true))}")

# Visualize the original data
plt.figure(figsize=(18, 12))

# Plot 1: Original data
plt.subplot(3, 4, 1)
plt.scatter(X[:, 0], X[:, 1], c=y_true, cmap='viridis', alpha=0.7)
plt.title('Original Data with True Clusters')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.colorbar()

# Example 2: Different Linkage Methods
print("\n2. Testing Different Linkage Methods...")

linkage_methods = ['ward', 'complete', 'average', 'single']
n_clusters = 4

for i, method in enumerate(linkage_methods):
    # Apply Agglomerative Clustering
    agg_clustering = AgglomerativeClustering(n_clusters=n_clusters, linkage=method)
    y_pred = agg_clustering.fit_predict(X)
    
    # Calculate silhouette score
    sil_score = silhouette_score(X, y_pred)
    ari_score = adjusted_rand_score(y_true, y_pred)
    
    print(f"{method.capitalize()} linkage - Silhouette: {sil_score:.4f}, ARI: {ari_score:.4f}")
    
    # Plot results
    plt.subplot(3, 4, i + 2)
    plt.scatter(X[:, 0], X[:, 1], c=y_pred, cmap='viridis', alpha=0.7)
    plt.title(f'{method.capitalize()} Linkage\nSil: {sil_score:.3f}')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')

# Example 3: Dendrogram Analysis
print("\n" + "="*50)
print("DENDROGRAM ANALYSIS")
print("="*50)

# Create a smaller dataset for clear dendrogram visualization
X_small, y_small = make_blobs(n_samples=50, centers=3, cluster_std=0.8, 
                              random_state=42, n_features=2)

# Calculate linkage matrix for dendrogram
linkage_matrix = linkage(X_small, method='ward')

# Plot dendrogram
plt.subplot(3, 4, 6)
dendrogram(linkage_matrix, truncate_mode='level', p=5)
plt.title('Dendrogram (Ward Linkage)')
plt.xlabel('Sample Index or (Cluster Size)')
plt.ylabel('Distance')

# Plot dendrogram with different linkage methods
plt.subplot(3, 4, 7)
linkage_complete = linkage(X_small, method='complete')
dendrogram(linkage_complete, truncate_mode='level', p=5)
plt.title('Dendrogram (Complete Linkage)')
plt.xlabel('Sample Index or (Cluster Size)')
plt.ylabel('Distance')

# Example 4: Determining Optimal Number of Clusters
print("\n3. Finding Optimal Number of Clusters...")

# Test different numbers of clusters
k_range = range(2, 11)
silhouette_scores = []
ari_scores = []

for k in k_range:
    agg_clustering = AgglomerativeClustering(n_clusters=k, linkage='ward')
    y_pred = agg_clustering.fit_predict(X)
    
    sil_score = silhouette_score(X, y_pred)
    ari_score = adjusted_rand_score(y_true, y_pred)
    
    silhouette_scores.append(sil_score)
    ari_scores.append(ari_score)

# Plot silhouette scores
plt.subplot(3, 4, 8)
plt.plot(k_range, silhouette_scores, 'bo-')
plt.xlabel('Number of Clusters')
plt.ylabel('Silhouette Score')
plt.title('Silhouette Score vs Clusters')
plt.grid(True)

# Find optimal k
optimal_k = k_range[np.argmax(silhouette_scores)]
print(f"Optimal number of clusters: {optimal_k}")
print(f"Best silhouette score: {max(silhouette_scores):.4f}")

# Example 5: Distance Matrix Visualization
print("\n4. Distance Matrix Analysis...")

# Calculate distance matrix
distance_matrix = pdist(X_small, metric='euclidean')
distance_matrix_square = squareform(distance_matrix)

# Plot distance matrix
plt.subplot(3, 4, 9)
sns.heatmap(distance_matrix_square, cmap='viridis', square=True, cbar=True)
plt.title('Distance Matrix Heatmap')
plt.xlabel('Sample Index')
plt.ylabel('Sample Index')

# Example 6: Real-world Example - Customer Segmentation
print("\n" + "="*50)
print("REAL-WORLD EXAMPLE: CUSTOMER SEGMENTATION")
print("="*50)

# Create realistic customer data
np.random.seed(42)
n_customers = 200

# Generate customer features
age = np.random.normal(40, 12, n_customers)
income = np.random.normal(50000, 15000, n_customers)
spending = np.random.uniform(20, 100, n_customers)
loyalty_years = np.random.exponential(3, n_customers)

# Create DataFrame
customer_data = pd.DataFrame({
    'Age': age,
    'Income': income,
    'Spending_Score': spending,
    'Loyalty_Years': loyalty_years
})

# Clean data
customer_data = customer_data[
    (customer_data['Age'] > 18) & 
    (customer_data['Age'] < 70) & 
    (customer_data['Income'] > 20000)
]

print("Customer Data Sample:")
print(customer_data.head())
print(f"\nDataset shape: {customer_data.shape}")

# Standardize features
scaler = StandardScaler()
customer_scaled = scaler.fit_transform(customer_data)

# Apply hierarchical clustering
print("\n5. Applying Hierarchical Clustering to Customer Data...")

# Find optimal clusters using silhouette analysis
k_range_customer = range(2, 8)
sil_scores_customer = []

for k in k_range_customer:
    agg_customer = AgglomerativeClustering(n_clusters=k, linkage='ward')
    labels = agg_customer.fit_predict(customer_scaled)
    sil_score = silhouette_score(customer_scaled, labels)
    sil_scores_customer.append(sil_score)
    print(f"k={k}: Silhouette Score = {sil_score:.4f}")

optimal_k_customer = k_range_customer[np.argmax(sil_scores_customer)]
print(f"\nOptimal number of customer segments: {optimal_k_customer}")

# Apply optimal clustering
agg_customer_final = AgglomerativeClustering(n_clusters=optimal_k_customer, linkage='ward')
customer_clusters = agg_customer_final.fit_predict(customer_scaled)

# Add cluster labels to original data
customer_data['Cluster'] = customer_clusters

# Plot customer segments
plt.subplot(3, 4, 10)
scatter = plt.scatter(customer_data['Income'], customer_data['Spending_Score'], 
                     c=customer_clusters, cmap='viridis', alpha=0.7)
plt.xlabel('Income')
plt.ylabel('Spending Score')
plt.title('Customer Segments')
plt.colorbar(scatter)

# Create dendrogram for customer data (subset for clarity)
customer_subset = customer_scaled[:50]  # Use subset for clear visualization
linkage_customers = linkage(customer_subset, method='ward')

plt.subplot(3, 4, 11)
dendrogram(linkage_customers, truncate_mode='level', p=4)
plt.title('Customer Dendrogram')
plt.xlabel('Customer Index')
plt.ylabel('Distance')

# Analyze customer segments
print(f"\n6. Customer Segment Analysis:")
segment_analysis = customer_data.groupby('Cluster').agg({
    'Age': ['mean', 'std', 'count'],
    'Income': ['mean', 'std'],
    'Spending_Score': ['mean', 'std'],
    'Loyalty_Years': ['mean', 'std']
}).round(2)

print(segment_analysis)

# Create detailed segment profiles
print(f"\n7. Detailed Customer Segment Profiles:")
for cluster_id in range(optimal_k_customer):
    cluster_data = customer_data[customer_data['Cluster'] == cluster_id]
    print(f"\nSegment {cluster_id} (n={len(cluster_data)}):")
    print(f"  Average Age: {cluster_data['Age'].mean():.1f} ± {cluster_data['Age'].std():.1f} years")
    print(f"  Average Income: ${cluster_data['Income'].mean():,.0f} ± ${cluster_data['Income'].std():,.0f}")
    print(f"  Average Spending Score: {cluster_data['Spending_Score'].mean():.1f} ± {cluster_data['Spending_Score'].std():.1f}")
    print(f"  Average Loyalty: {cluster_data['Loyalty_Years'].mean():.1f} ± {cluster_data['Loyalty_Years'].std():.1f} years")
    
    # Segment characteristics
    if cluster_data['Age'].mean() < 35:
        age_desc = "Young"
    elif cluster_data['Age'].mean() < 50:
        age_desc = "Middle-aged"
    else:
        age_desc = "Mature"
    
    if cluster_data['Income'].mean() < 40000:
        income_desc = "Lower income"
    elif cluster_data['Income'].mean() < 60000:
        income_desc = "Middle income"
    else:
        income_desc = "Higher income"
    
    if cluster_data['Spending_Score'].mean() < 40:
        spending_desc = "Low spenders"
    elif cluster_data['Spending_Score'].mean() < 70:
        spending_desc = "Moderate spenders"
    else:
        spending_desc = "High spenders"
    
    print(f"  Profile: {age_desc}, {income_desc}, {spending_desc}")

# Example 7: Comparison with K-Means
print("\n" + "="*50)
print("COMPARISON WITH K-MEANS CLUSTERING")
print("="*50)

from sklearn.cluster import KMeans

# Apply K-Means for comparison
kmeans_customer = KMeans(n_clusters=optimal_k_customer, random_state=42, n_init=10)
kmeans_labels = kmeans_customer.fit_predict(customer_scaled)

# Compare results
hierarchical_sil = silhouette_score(customer_scaled, customer_clusters)
kmeans_sil = silhouette_score(customer_scaled, kmeans_labels)

print(f"Hierarchical Clustering Silhouette Score: {hierarchical_sil:.4f}")
print(f"K-Means Clustering Silhouette Score: {kmeans_sil:.4f}")

# Plot comparison
plt.subplot(3, 4, 12)
plt.scatter(customer_data['Income'], customer_data['Spending_Score'], 
           c=kmeans_labels, cmap='viridis', alpha=0.7)
plt.xlabel('Income')
plt.ylabel('Spending Score')
plt.title(f'K-Means Segments\nSil: {kmeans_sil:.3f}')

plt.tight_layout()
plt.savefig('hierarchical_clustering_analysis.png', dpi=300, bbox_inches='tight')
print('Saved: hierarchical_clustering_analysis.png')
plt.close()

# Create a separate figure for detailed dendrogram
plt.figure(figsize=(15, 8))

# Full dendrogram for customer data
plt.subplot(1, 2, 1)
linkage_full = linkage(customer_scaled, method='ward')
dendrogram(linkage_full, truncate_mode='level', p=6)
plt.title('Complete Customer Dendrogram (Ward Linkage)')
plt.xlabel('Customer Index or (Cluster Size)')
plt.ylabel('Distance')

# Horizontal dendrogram
plt.subplot(1, 2, 2)
dendrogram(linkage_full, orientation='left', truncate_mode='level', p=6)
plt.title('Horizontal Dendrogram')
plt.xlabel('Distance')
plt.ylabel('Customer Index or (Cluster Size)')

plt.tight_layout()
plt.savefig('hierarchical_dendrograms.png', dpi=300, bbox_inches='tight')
print('Saved: hierarchical_dendrograms.png')
plt.close()

# Example predictions for new customers
print(f"\n8. Predicting Segments for New Customers:")
print("Note: Hierarchical clustering doesn't directly predict new samples.")
print("We can use nearest centroid approach or retrain with new data.")

# Calculate centroids for each cluster
cluster_centroids = []
for cluster_id in range(optimal_k_customer):
    cluster_mask = customer_clusters == cluster_id
    centroid = customer_scaled[cluster_mask].mean(axis=0)
    cluster_centroids.append(centroid)

cluster_centroids = np.array(cluster_centroids)

# Example new customers
new_customers = np.array([
    [28, 35000, 75, 1.5],  # Young, lower income, high spending, new
    [45, 65000, 45, 8.0],  # Middle-aged, higher income, moderate spending, loyal
    [38, 50000, 60, 4.0]   # Middle-aged, middle income, moderate-high spending
])

# Scale new customers
new_customers_scaled = scaler.transform(new_customers)

# Find closest cluster for each new customer
for i, customer in enumerate(new_customers):
    distances = np.linalg.norm(new_customers_scaled[i] - cluster_centroids, axis=1)
    closest_cluster = np.argmin(distances)
    
    print(f"\nNew Customer {i+1}:")
    print(f"  Age: {customer[0]:.0f}, Income: ${customer[1]:,.0f}")
    print(f"  Spending Score: {customer[2]:.1f}, Loyalty: {customer[3]:.1f} years")
    print(f"  Closest Segment: {closest_cluster}")
    print(f"  Distance to centroid: {distances[closest_cluster]:.4f}")

print("\n" + "="*50)
print("Hierarchical Clustering Example Complete!")
print("Files saved:")
print("- hierarchical_clustering_analysis.png")
print("- hierarchical_dendrograms.png")
print("="*50)