"""
Decision Tree Classifier - Complete Example
==========================================
This example demonstrates how to use Decision Tree Classifier for classification tasks.
"""

import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.datasets import make_classification
import matplotlib.pyplot as plt
from sklearn.tree import plot_tree
import seaborn as sns

print("Decision Tree Classifier Example")
print("=" * 40)

# Example 1: Simple Synthetic Dataset
print("\n1. Creating Synthetic Dataset...")
X, y = make_classification(n_samples=1000, n_features=4, n_informative=3, 
                          n_redundant=1, n_clusters_per_class=1, random_state=42)

# Create feature names
feature_names = ['Feature_1', 'Feature_2', 'Feature_3', 'Feature_4']
class_names = ['Class_0', 'Class_1']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

print(f"Training set size: {X_train.shape[0]} samples")
print(f"Test set size: {X_test.shape[0]} samples")

# Create and train the Decision Tree
print("\n2. Training Decision Tree...")
dt_classifier = DecisionTreeClassifier(
    max_depth=5,           # Limit tree depth to prevent overfitting
    min_samples_split=20,  # Minimum samples required to split a node
    min_samples_leaf=10,   # Minimum samples required at leaf node
    random_state=42
)

dt_classifier.fit(X_train, y_train)

# Make predictions
y_pred = dt_classifier.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f"\n3. Model Performance:")
print(f"Accuracy: {accuracy:.4f}")

# Detailed classification report
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=class_names))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:")
print(cm)

# Visualize the confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=class_names, yticklabels=class_names)
plt.title('Confusion Matrix - Decision Tree Classifier')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.tight_layout()
plt.savefig('decision_tree_confusion_matrix.png', dpi=300, bbox_inches='tight')
print('Saved: decision_tree_confusion_matrix.png')
plt.close()

# Feature Importance
feature_importance = dt_classifier.feature_importances_
print(f"\n4. Feature Importance:")
for i, importance in enumerate(feature_importance):
    print(f"{feature_names[i]}: {importance:.4f}")

# Plot feature importance
plt.figure(figsize=(10, 6))
plt.bar(feature_names, feature_importance)
plt.title('Feature Importance - Decision Tree Classifier')
plt.xlabel('Features')
plt.ylabel('Importance')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('decision_tree_feature_importance.png', dpi=300, bbox_inches='tight')
print('Saved: decision_tree_feature_importance.png')
plt.close()

# Visualize the decision tree (first few levels)
plt.figure(figsize=(20, 10))
plot_tree(dt_classifier, max_depth=3, feature_names=feature_names, 
          class_names=class_names, filled=True, rounded=True, fontsize=10)
plt.title('Decision Tree Structure (First 3 Levels)')
plt.tight_layout()
plt.savefig('decision_tree_structure.png', dpi=300, bbox_inches='tight')
print('Saved: decision_tree_structure.png')
plt.close()

# Example 2: Real-world example with Iris dataset
print("\n" + "="*50)
print("REAL-WORLD EXAMPLE: IRIS DATASET")
print("="*50)

from sklearn.datasets import load_iris

# Load Iris dataset
iris = load_iris()
X_iris = iris.data
y_iris = iris.target

# Split the data
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(
    X_iris, y_iris, test_size=0.3, random_state=42)

# Train decision tree on Iris dataset
dt_iris = DecisionTreeClassifier(max_depth=4, random_state=42)
dt_iris.fit(X_train_iris, y_train_iris)

# Make predictions
y_pred_iris = dt_iris.predict(X_test_iris)

# Evaluate
accuracy_iris = accuracy_score(y_test_iris, y_pred_iris)
print(f"\nIris Dataset Results:")
print(f"Accuracy: {accuracy_iris:.4f}")

print("\nClassification Report:")
print(classification_report(y_test_iris, y_pred_iris, target_names=iris.target_names))

# Feature importance for Iris
print(f"\nFeature Importance (Iris Dataset):")
for i, importance in enumerate(dt_iris.feature_importances_):
    print(f"{iris.feature_names[i]}: {importance:.4f}")

# Example prediction
print(f"\n5. Example Predictions:")
print("Making predictions on new samples...")

# Create some example data points
new_samples = np.array([[5.1, 3.5, 1.4, 0.2],  # Should be Setosa
                       [6.2, 2.8, 4.8, 1.8],   # Should be Virginica
                       [5.7, 2.8, 4.1, 1.3]])  # Should be Versicolor

predictions = dt_iris.predict(new_samples)
probabilities = dt_iris.predict_proba(new_samples)

for i, (sample, pred, prob) in enumerate(zip(new_samples, predictions, probabilities)):
    print(f"\nSample {i+1}: {sample}")
    print(f"Predicted class: {iris.target_names[pred]}")
    print(f"Probabilities: {dict(zip(iris.target_names, prob))}")

print(f"\n6. Model Parameters:")
print(f"Max depth: {dt_iris.max_depth}")
print(f"Number of features: {dt_iris.n_features_in_}")
print(f"Number of classes: {dt_iris.n_classes_}")
print(f"Tree depth: {dt_iris.get_depth()}")
print(f"Number of leaves: {dt_iris.get_n_leaves()}")

print("\n" + "="*50)
print("Decision Tree Classifier Example Complete!")
print("Files saved:")
print("- decision_tree_confusion_matrix.png")
print("- decision_tree_feature_importance.png") 
print("- decision_tree_structure.png")
print("="*50)