"""
Apriori Algorithm - Complete Example
====================================
This example demonstrates how to use the Apriori Algorithm for Market Basket Analysis
and Association Rule Mining.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from itertools import combinations

# Since mlxtend might not be installed, we'll implement a simple version
# and also show how to use mlxtend if available

print("Apriori Algorithm Example")
print("=" * 30)

# Example 1: Simple Apriori Implementation
print("\n1. Creating Transaction Dataset...")

# Create sample transaction data
transactions = [
    ['Milk', 'Eggs', 'Bread', 'Cheese'],
    ['Milk', 'Eggs'],
    ['Milk', 'Bread'],
    ['Eggs', 'Bread', 'Butter'],
    ['Milk', 'Eggs', 'Bread', 'Butter', 'Cheese'],
    ['Milk', 'Eggs', 'Butter'],
    ['Eggs', 'Bread'],
    ['Milk', 'Bread', 'Butter'],
    ['Milk', 'Eggs', 'Cheese'],
    ['Bread', 'Butter']
]

print(f"Sample transactions:")
for i, transaction in enumerate(transactions[:5]):
    print(f"Transaction {i+1}: {', '.join(transaction)}")
print("...")

# Convert to DataFrame for better analysis
transaction_df = pd.DataFrame({
    'Transaction_ID': range(1, len(transactions) + 1),
    'Items': transactions
})

print(f"\nTotal transactions: {len(transactions)}")

# Get all unique items
all_items = set()
for transaction in transactions:
    all_items.update(transaction)
print(f"Unique items: {sorted(all_items)}")

class SimpleApriori:
    def __init__(self, transactions, min_support=0.3):
        self.transactions = transactions
        self.min_support = min_support
        self.n_transactions = len(transactions)
        self.min_support_count = int(min_support * self.n_transactions)
        
    def get_item_support(self, itemset):
        """Calculate support for an itemset"""
        count = 0
        for transaction in self.transactions:
            if set(itemset).issubset(set(transaction)):
                count += 1
        return count / self.n_transactions
    
    def get_frequent_1_itemsets(self):
        """Find frequent 1-itemsets"""
        item_counts = {}
        for transaction in self.transactions:
            for item in transaction:
                item_counts[item] = item_counts.get(item, 0) + 1
        
        frequent_items = {}
        for item, count in item_counts.items():
            support = count / self.n_transactions
            if support >= self.min_support:
                frequent_items[frozenset([item])] = support
        
        return frequent_items
    
    def generate_candidates(self, frequent_itemsets, k):
        """Generate candidate k-itemsets from frequent (k-1)-itemsets"""
        candidates = set()
        frequent_list = list(frequent_itemsets.keys())
        
        for i in range(len(frequent_list)):
            for j in range(i + 1, len(frequent_list)):
                union = frequent_list[i] | frequent_list[j]
                if len(union) == k:
                    candidates.add(union)
        
        return candidates
    
    def run_apriori(self):
        """Run the Apriori algorithm"""
        all_frequent_itemsets = {}
        
        # Find frequent 1-itemsets
        print(f"\n2. Finding Frequent Itemsets (min_support = {self.min_support})...")
        frequent_1 = self.get_frequent_1_itemsets()
        all_frequent_itemsets.update(frequent_1)
        
        print(f"Frequent 1-itemsets: {len(frequent_1)}")
        for itemset, support in frequent_1.items():
            print(f"  {set(itemset)}: {support:.3f}")
        
        current_frequent = frequent_1
        k = 2
        
        while current_frequent:
            # Generate candidates
            candidates = self.generate_candidates(current_frequent, k)
            
            # Check support for candidates
            frequent_k = {}
            for candidate in candidates:
                support = self.get_item_support(candidate)
                if support >= self.min_support:
                    frequent_k[candidate] = support
            
            if frequent_k:
                all_frequent_itemsets.update(frequent_k)
                print(f"\nFrequent {k}-itemsets: {len(frequent_k)}")
                for itemset, support in frequent_k.items():
                    print(f"  {set(itemset)}: {support:.3f}")
            
            current_frequent = frequent_k
            k += 1
        
        return all_frequent_itemsets
    
    def generate_association_rules(self, frequent_itemsets, min_confidence=0.6):
        """Generate association rules from frequent itemsets"""
        rules = []
        
        print(f"\n3. Generating Association Rules (min_confidence = {min_confidence})...")
        
        for itemset, support in frequent_itemsets.items():
            if len(itemset) > 1:
                # Generate all possible rules for this itemset
                items = list(itemset)
                
                # Generate all non-empty proper subsets
                for i in range(1, len(items)):
                    for antecedent in combinations(items, i):
                        antecedent = frozenset(antecedent)
                        consequent = itemset - antecedent
                        
                        # Calculate confidence
                        antecedent_support = frequent_itemsets.get(antecedent, 0)
                        if antecedent_support > 0:
                            confidence = support / antecedent_support
                            
                            if confidence >= min_confidence:
                                # Calculate lift
                                consequent_support = self.get_item_support(consequent)
                                lift = confidence / consequent_support if consequent_support > 0 else 0
                                
                                rules.append({
                                    'antecedent': set(antecedent),
                                    'consequent': set(consequent),
                                    'support': support,
                                    'confidence': confidence,
                                    'lift': lift
                                })
        
        # Sort rules by confidence
        rules.sort(key=lambda x: x['confidence'], reverse=True)
        
        print(f"Generated {len(rules)} association rules:")
        for i, rule in enumerate(rules[:10]):  # Show top 10 rules
            print(f"Rule {i+1}: {rule['antecedent']} → {rule['consequent']}")
            print(f"  Support: {rule['support']:.3f}, Confidence: {rule['confidence']:.3f}, Lift: {rule['lift']:.3f}")
        
        return rules

# Run the simple Apriori algorithm
apriori = SimpleApriori(transactions, min_support=0.3)
frequent_itemsets = apriori.run_apriori()
association_rules = apriori.generate_association_rules(frequent_itemsets, min_confidence=0.6)

# Example 2: Larger Dataset Example
print("\n" + "="*60)
print("LARGER DATASET EXAMPLE - GROCERY STORE")
print("="*60)

# Create a larger, more realistic dataset
np.random.seed(42)

# Define product categories
products = {
    'dairy': ['Milk', 'Cheese', 'Yogurt', 'Butter'],
    'bakery': ['Bread', 'Croissant', 'Muffin'],
    'meat': ['Chicken', 'Beef', 'Pork'],
    'produce': ['Apples', 'Bananas', 'Carrots', 'Lettuce'],
    'beverages': ['Coffee', 'Tea', 'Juice'],
    'snacks': ['Chips', 'Cookies', 'Crackers']
}

all_products = []
for category, items in products.items():
    all_products.extend(items)

# Generate transactions with realistic patterns
large_transactions = []

for i in range(1000):
    transaction = []
    
    # Add some randomness but with realistic patterns
    # People often buy from multiple categories
    n_categories = np.random.choice([1, 2, 3, 4], p=[0.2, 0.4, 0.3, 0.1])
    selected_categories = np.random.choice(list(products.keys()), n_categories, replace=False)
    
    for category in selected_categories:
        # Select 1-3 items from each selected category
        n_items = np.random.choice([1, 2, 3], p=[0.5, 0.3, 0.2])
        selected_items = np.random.choice(products[category], min(n_items, len(products[category])), replace=False)
        transaction.extend(selected_items)
    
    large_transactions.append(transaction)

# Filter out empty transactions
large_transactions = [t for t in large_transactions if len(t) > 0]

print(f"Generated {len(large_transactions)} transactions")
print(f"Average transaction size: {np.mean([len(t) for t in large_transactions]):.1f} items")

# Sample transactions
print(f"\nSample transactions:")
for i in range(5):
    print(f"Transaction {i+1}: {', '.join(large_transactions[i])}")

# Run Apriori on larger dataset
print(f"\n4. Running Apriori on Larger Dataset...")
large_apriori = SimpleApriori(large_transactions, min_support=0.1)
large_frequent_itemsets = large_apriori.run_apriori()
large_rules = large_apriori.generate_association_rules(large_frequent_itemsets, min_confidence=0.5)

# Analysis and Visualization
print(f"\n5. Analysis and Insights...")

# Create binary matrix for visualization
def create_binary_matrix(transactions, items):
    """Create binary transaction matrix"""
    matrix = []
    for transaction in transactions:
        row = [1 if item in transaction else 0 for item in items]
        matrix.append(row)
    return np.array(matrix)

# Create binary matrix for visualization (using first 100 transactions)
items_for_viz = sorted(all_products)
binary_matrix = create_binary_matrix(large_transactions[:100], items_for_viz)

# Plot transaction matrix
plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
plt.imshow(binary_matrix.T, cmap='Blues', aspect='auto')
plt.xlabel('Transaction ID')
plt.ylabel('Items')
plt.title('Transaction Matrix (First 100 Transactions)')
plt.yticks(range(len(items_for_viz)), items_for_viz, fontsize=8)

# Item frequency analysis
item_frequencies = {}
for transaction in large_transactions:
    for item in transaction:
        item_frequencies[item] = item_frequencies.get(item, 0) + 1

# Sort by frequency
sorted_items = sorted(item_frequencies.items(), key=lambda x: x[1], reverse=True)

# Plot item frequencies
plt.subplot(2, 2, 2)
items, frequencies = zip(*sorted_items[:15])  # Top 15 items
plt.bar(range(len(items)), frequencies)
plt.xlabel('Items')
plt.ylabel('Frequency')
plt.title('Top 15 Most Frequent Items')
plt.xticks(range(len(items)), items, rotation=45, ha='right')

# Support distribution of frequent itemsets
supports = list(large_frequent_itemsets.values())
plt.subplot(2, 2, 3)
plt.hist(supports, bins=20, alpha=0.7, edgecolor='black')
plt.xlabel('Support')
plt.ylabel('Frequency')
plt.title('Distribution of Support Values')

# Rule confidence distribution
if large_rules:
    confidences = [rule['confidence'] for rule in large_rules]
    plt.subplot(2, 2, 4)
    plt.hist(confidences, bins=20, alpha=0.7, edgecolor='black')
    plt.xlabel('Confidence')
    plt.ylabel('Frequency')
    plt.title('Distribution of Rule Confidences')

plt.tight_layout()
plt.savefig('apriori_analysis.png', dpi=300, bbox_inches='tight')
print('Saved: apriori_analysis.png')
plt.close()

# Example 3: Using mlxtend library (if available)
print("\n" + "="*60)
print("USING MLXTEND LIBRARY (PROFESSIONAL IMPLEMENTATION)")
print("="*60)

try:
    from mlxtend.frequent_patterns import apriori, association_rules
    from mlxtend.preprocessing import TransactionEncoder
    
    print("mlxtend library found! Using professional implementation...")
    
    # Convert transactions to the format required by mlxtend
    te = TransactionEncoder()
    te_ary = te.fit(large_transactions).transform(large_transactions)
    df_mlx = pd.DataFrame(te_ary, columns=te.columns_)
    
    print(f"Transaction matrix shape: {df_mlx.shape}")
    print(f"Sample of transaction matrix:")
    print(df_mlx.head())
    
    # Apply Apriori algorithm
    frequent_itemsets_mlx = apriori(df_mlx, min_support=0.1, use_colnames=True)
    print(f"\nFrequent itemsets found: {len(frequent_itemsets_mlx)}")
    print(frequent_itemsets_mlx.head(10))
    
    # Generate association rules
    if len(frequent_itemsets_mlx) > 0:
        rules_mlx = association_rules(frequent_itemsets_mlx, metric="confidence", min_threshold=0.5)
        print(f"\nAssociation rules found: {len(rules_mlx)}")
        
        if len(rules_mlx) > 0:
            # Display top rules
            print(f"Top 10 association rules by confidence:")
            top_rules = rules_mlx.nlargest(10, 'confidence')
            print(top_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])
            
            # Visualize rules
            plt.figure(figsize=(12, 8))
            
            plt.subplot(2, 2, 1)
            plt.scatter(rules_mlx['support'], rules_mlx['confidence'], alpha=0.6)
            plt.xlabel('Support')
            plt.ylabel('Confidence')
            plt.title('Support vs Confidence')
            
            plt.subplot(2, 2, 2)
            plt.scatter(rules_mlx['support'], rules_mlx['lift'], alpha=0.6)
            plt.xlabel('Support')
            plt.ylabel('Lift')
            plt.title('Support vs Lift')
            
            plt.subplot(2, 2, 3)
            plt.scatter(rules_mlx['confidence'], rules_mlx['lift'], alpha=0.6)
            plt.xlabel('Confidence')
            plt.ylabel('Lift')
            plt.title('Confidence vs Lift')
            
            plt.subplot(2, 2, 4)
            plt.hist(rules_mlx['lift'], bins=20, alpha=0.7, edgecolor='black')
            plt.xlabel('Lift')
            plt.ylabel('Frequency')
            plt.title('Distribution of Lift Values')
            
            plt.tight_layout()
            plt.savefig('apriori_rules_analysis.png', dpi=300, bbox_inches='tight')
            print('Saved: apriori_rules_analysis.png')
            plt.close()
    
except ImportError:
    print("mlxtend library not available.")
    print("To install: pip install mlxtend")
    print("Continuing with our simple implementation...")

# Example 4: Market Basket Analysis Insights
print(f"\n6. Market Basket Analysis Insights...")

# Analyze the best rules
if large_rules:
    print(f"\nTop Association Rules Analysis:")
    
    # Group rules by lift value
    high_lift_rules = [rule for rule in large_rules if rule['lift'] > 1.5]
    medium_lift_rules = [rule for rule in large_rules if 1.0 < rule['lift'] <= 1.5]
    
    print(f"High lift rules (>1.5): {len(high_lift_rules)}")
    print(f"Medium lift rules (1.0-1.5): {len(medium_lift_rules)}")
    
    # Show most interesting rules
    print(f"\nMost Interesting Rules (High Lift & Confidence):")
    interesting_rules = [rule for rule in large_rules if rule['lift'] > 1.2 and rule['confidence'] > 0.7]
    
    for i, rule in enumerate(interesting_rules[:5]):
        print(f"\nRule {i+1}: {rule['antecedent']} → {rule['consequent']}")
        print(f"  Support: {rule['support']:.3f} ({rule['support']*len(large_transactions):.0f} transactions)")
        print(f"  Confidence: {rule['confidence']:.3f} ({rule['confidence']*100:.1f}% of people who buy {rule['antecedent']} also buy {rule['consequent']})")
        print(f"  Lift: {rule['lift']:.3f} ({rule['lift']:.1f}x more likely than random)")

# Practical recommendations
print(f"\n7. Business Recommendations:")
print("Based on the association rules found:")

# Find the most frequent item pairs
item_pairs = {}
for itemset, support in large_frequent_itemsets.items():
    if len(itemset) == 2:
        pair = tuple(sorted(itemset))
        item_pairs[pair] = support

if item_pairs:
    top_pairs = sorted(item_pairs.items(), key=lambda x: x[1], reverse=True)[:5]
    
    print(f"\nTop item pairs frequently bought together:")
    for i, (pair, support) in enumerate(top_pairs):
        print(f"{i+1}. {pair[0]} & {pair[1]} (Support: {support:.3f})")
    
    print(f"\nRecommendations:")
    print("1. Place these frequently paired items near each other in the store")
    print("2. Create bundle offers for these item combinations")
    print("3. Use these patterns for cross-selling recommendations")
    print("4. Ensure adequate stock levels for both items in pairs")

# Summary statistics
print(f"\n8. Summary Statistics:")
print(f"Total transactions analyzed: {len(large_transactions)}")
print(f"Unique items: {len(set(item for transaction in large_transactions for item in transaction))}")
print(f"Average transaction size: {np.mean([len(t) for t in large_transactions]):.1f} items")
print(f"Frequent itemsets found: {len(large_frequent_itemsets)}")
print(f"Association rules generated: {len(large_rules) if large_rules else 0}")
print(f"Minimum support used: {large_apriori.min_support}")
print(f"Minimum confidence used: 0.5")

print("\n" + "="*60)
print("Apriori Algorithm Example Complete!")
print("Files saved:")
print("- apriori_analysis.png")
if 'rules_mlx' in locals() and len(rules_mlx) > 0:
    print("- apriori_rules_analysis.png")
print("="*60)

# Additional: Save results to CSV
print(f"\n9. Saving Results...")

# Save frequent itemsets
if large_frequent_itemsets:
    itemsets_data = []
    for itemset, support in large_frequent_itemsets.items():
        itemsets_data.append({
            'itemset': ', '.join(sorted(itemset)),
            'size': len(itemset),
            'support': support
        })
    
    itemsets_df = pd.DataFrame(itemsets_data)
    itemsets_df.to_csv('frequent_itemsets.csv', index=False)
    print("Frequent itemsets saved to: frequent_itemsets.csv")

# Save association rules
if large_rules:
    rules_data = []
    for rule in large_rules:
        rules_data.append({
            'antecedent': ', '.join(sorted(rule['antecedent'])),
            'consequent': ', '.join(sorted(rule['consequent'])),
            'support': rule['support'],
            'confidence': rule['confidence'],
            'lift': rule['lift']
        })
    
    rules_df = pd.DataFrame(rules_data)
    rules_df.to_csv('association_rules.csv', index=False)
    print("Association rules saved to: association_rules.csv")